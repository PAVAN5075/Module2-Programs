package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.bean.Day;
import com.cg.bean.Game;

public interface SportsDao 
{
	/*Day save(String day,List<Game> g);
	Day findByDayName(String name);
	List<Day> findByGameName(String name);*/
	
	@Query(value="select e from Day e where e.name=(:id)")
	Day findByDayName(@Param(value="id")String id);
	@Query(value="select d from Day d inner join d.game g where g.name=(:name)")
	List<Day> findByGameName(@Param(value="name")String name); 
}
