package com.cg.ui;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.support.GenericXmlApplicationContext;

import com.cg.bean.Day;
import com.cg.bean.Game;
import com.cg.dao.SportsDao;
import com.cg.dao.SportsDaoImpl;
import com.cg.service.SportsService;
import com.cg.service.SportsServiceImpl;

public class Client {

	public static void main(String[] args) 
	{
		GenericXmlApplicationContext ct= new GenericXmlApplicationContext("beanConfig.xml");
		SportsService service=ct.getBean("service",SportsService.class);
		/*
		Day d1 = new Day();
		
		Game g11 = new Game();
		g11.setGameName("Hockey");
		Game g12 = new Game();
		g12.setGameName("Cricket");
		Game g13 = new Game();
		g13.setGameName("Football");
		Game g14 = new Game();
		g14.setGameName("Cricket");
		Game g15 = new Game();
		g15.setGameName("Football");
		
		List<Game> day1 = new ArrayList<Game>();
		day1.add(g11);
		day1.add(g12);
		day1.add(g13);
		
		List<Game> day12 = new ArrayList<Game>();
		day12.add(g11);
		day12.add(g12);
		day12.add(g14);
		day12.add(g15);
		
		d1.setDayNo("Day 1");
		d1.setGames(day1);
		Day d2 = service.addDay("Day 1", day1);
		System.out.println(d2);		

		d1.setDayNo("Day 2");
		d1.setGames(day12);
		Day d3 = service.addDay("Day 2", day12);
		System.out.println(d3);*/
		
		Day day = service.findByDay("Day 1");
		System.out.println(day.getGames());
		
		List<Day> days1 = service.findByGame("Hockey");
		for (Day day2 : days1) {
			System.out.println(day2.getDayNo());
		}
		
		
	}
}
