package com.cg.bean;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Day {
	 @Id
	@GeneratedValue
	private int dId;
	
	private String dayNo;
	@OneToMany (cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Game> games;
	
	
	public String getDayNo() {
		return dayNo;
	}
	public void setDayNo(String dayNo) {
		this.dayNo = dayNo;
	}
	public List<Game> getGames() {
		return games;
	}
	public void setGames(List<Game> games) {
		this.games = games;
	}
	public int getdId() {
		return dId;
	}
	public void setdId(int dId) {
		this.dId = dId;
	}
	
	@Override
	public String toString() {
		return "Day [dayNo=" + dayNo + ", games=" + games + ", dId=" + dId + "]";
	}
	
}
