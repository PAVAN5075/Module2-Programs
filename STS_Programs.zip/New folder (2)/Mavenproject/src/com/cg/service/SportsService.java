package com.cg.service;

import java.util.List;
import com.cg.bean.Day;
import com.cg.bean.Game;

public interface SportsService {
	Day addDay(String day,List<Game> g);
	Day findByDay(String name);
	List<Day> findByGame(String name);
}
