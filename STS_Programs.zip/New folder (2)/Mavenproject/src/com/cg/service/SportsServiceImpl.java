package com.cg.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.bean.Day;
import com.cg.bean.Game;
import com.cg.dao.SportsDao;

@Service(value="service")
public class SportsServiceImpl implements SportsService{
	
	@Autowired
	private SportsDao repo;
	
	public Day addDay(String day, List<Game> g) {
		return repo.save(day, g);
	}

	public Day findByDay(String name) {
		return repo.findByDayName(name);
	}
	
	public List<Day> findByGame(String name) {
		return repo.findByGameName(name);
	}
}
