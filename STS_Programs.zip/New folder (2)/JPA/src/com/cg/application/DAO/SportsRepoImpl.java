package com.cg.application.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.application.bean.Day;
@Repository
public class SportsRepoImpl implements SportsRepo {
	@PersistenceContext
	protected EntityManager em;
	
	
	/*public SportsRepoImpl(EntityManager em) {
	
		this.em = em;
	}*/
	
	@Transactional
	@Override
	public Day addDay(Day day) {
		em.getTransaction().begin();
		em.persist(day);
		em.getTransaction().commit();
		return day;
	}
/*
	@Override
	public Day findByDayName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Day> findByGameName(String name) {
		// TODO Auto-generated method stub
		return null;
	}*/

}
