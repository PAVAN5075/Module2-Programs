package com.cg.application.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.application.bean.Day;

public interface SportsRepo extends JpaRepository<Day, String>
{
	
	
	
	
	
	Day addDay(Day day);
	/*Day findByDayName(String name);
	List<Day> findByGameName(String name);*/

}
