package com.cg.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.exception.EmployeeException;
import com.cg.model.Employee;
import com.cg.repo.EmployeeRepo;
@Service
@PersistenceContext
public class EmployeeService implements IEmployeeService {
	@Autowired
	private EmployeeRepo repo;
	@Autowired
	private EntityManager em;
	
	
	public boolean validateName(String name) throws EmployeeException{
		if(name.isEmpty() ||name==null){
			throw new EmployeeException("Employee name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-za-z]{2,}")){
				throw new EmployeeException("Employee name should start with capital letter and should contain only alphabets and size should be greater than two");
			}
		}
		return true;
	}
	
	
	@Override
	public Employee addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		boolean b=validateName(employee.getEname());
		
		if(b) {
		repo.save(employee);
		}else {
			throw new EmployeeException("Validation Failed");
		}
		
		
		return employee;
	}


	@Override
	public Employee updateEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		Employee employee2=repo.getEmployeeById(employee.getEid());
		String name=employee.getEname();
		String project=employee.getProject();
		double salary=employee.getSalary();
		if(name!=null) {
			employee2.setEname(employee.getEname());
		}
		if(project!=null) {
			employee2.setProject(employee.getProject());
		}
		
		if(salary!=0) {
			employee2.setSalary(employee.getSalary());
		}
		repo.save(employee2);
		
		
		return employee2;
	}


	@Override
	public String deleteEmployee(String id) throws EmployeeException {
		// TODO Auto-generated method stub

		repo.deleteById(id);
		return id;
	}


	@Override
	public List<Employee> viewAllEmployees() throws EmployeeException {
		// TODO Auto-generated method stub
		return repo.findAll();
	}


	@Override
	public Employee findEmployeeById(String id) throws EmployeeException {
		// TODO Auto-generated method stub
		
		return repo.getOne(id);
	}
	

}
