package com.cg.service;

import java.util.List;

import com.cg.exception.EmployeeException;
import com.cg.model.Employee;

public interface IEmployeeService {
	
	Employee addEmployee(Employee employee) throws EmployeeException;
	Employee updateEmployee(Employee employee)throws EmployeeException;
	String deleteEmployee(String id)throws EmployeeException;
	List<Employee> viewAllEmployees() throws EmployeeException;
	Employee findEmployeeById(String id)throws EmployeeException;

}
