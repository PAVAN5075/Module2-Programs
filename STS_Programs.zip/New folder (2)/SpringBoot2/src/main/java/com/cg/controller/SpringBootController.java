package com.cg.controller;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.exception.EmployeeException;
import com.cg.model.Employee;
import com.cg.service.IEmployeeService;

@RestController
@Transactional
@PersistenceContext
public class SpringBootController {
	
	@Autowired
	private IEmployeeService service;
	
	
	@RequestMapping(value="/addEmployee",method=RequestMethod.POST)
	public Employee addEmployee(@RequestBody Employee employee) throws EmployeeException {
		
		try {
			Employee employee2=service.addEmployee(employee);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			throw new EmployeeException(e.getMessage());
		}
		
		
		return employee;
		
	}
	@RequestMapping(value="/updateEmployee",method=RequestMethod.PUT)
	public Employee updateEmployee(@RequestBody Employee employee) {
		
		try {
			employee=service.updateEmployee(employee);
			
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		return employee;
		
	}

	@RequestMapping(value="/deleteEmployee",method=RequestMethod.DELETE)
	public String deleteEmployee(String id) {
		
		
		try {
			service.deleteEmployee(id);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		
		return id;
		
	}
	@RequestMapping(value="/viewAllEmployees",method=RequestMethod.GET)
	public List<Employee> viewAllEmployees() {
		List<Employee> employees=null;
		try {
			employees=service.viewAllEmployees();
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		return employees;
		
	}
	@RequestMapping(value="/findEmployeeById",method=RequestMethod.GET)
	public Employee findEmployeeById(String id) {
		Employee employee=null;
		try {
			employee=service.findEmployeeById(id);
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		return employee;
		
		
	}
}
