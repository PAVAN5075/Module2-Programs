package com.cg.Exception;

public class PaymentException extends Exception {
	PaymentException()
	{
		super();
	}
	public PaymentException(String message)
	{
		super(message);
	}

}
