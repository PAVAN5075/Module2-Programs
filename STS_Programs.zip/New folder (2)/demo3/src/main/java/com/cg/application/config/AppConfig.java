package com.cg.application.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.cg.application.bean.Day;
import com.cg.application.bean.Game;

@Configuration
@ComponentScan(basePackages= {"com.cg.application"})
public class AppConfig {
	
@Bean
@Scope("singleton")
	public Map<String,Day> getMap() {
	
	Map<String,Day> map=new HashMap<String,Day>();
	Day d6 = new Day();
	List<Game> day6 = new ArrayList<Game>();

	Game g61 = new Game();
	g61.setName("Throw Ball");
	Game g62 = new Game();
	g62.setName("Long Jump");
	Game g63 = new Game();
	g63.setName("High Jump");
	
	day6.add(g61);
	day6.add(g62);
	day6.add(g63);

	d6.setName("Day 6");
	d6.setGame(day6);
	map.put(d6.getName(), d6);
	return map;
	
}
}
