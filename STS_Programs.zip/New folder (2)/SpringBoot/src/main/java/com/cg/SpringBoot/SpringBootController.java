package com.cg.SpringBoot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.message;
import com.cg.model.sender;
import com.cg.repo.MessageRepo;

@RestController
public class SpringBootController {
	
	@Autowired
	MessageRepo repo;
	
	@RequestMapping(value="/")
	public String sayHello() {
		return "Spring Boot Controller";
	}
	
	@RequestMapping(value="/message")
	public message sendMessage() {
		message m=new message();
		sender s=new sender();
		s.setName("Pavan");
		m.setText("Spring Boot");
		m.setSend(s);	
		return m;
	}
	
	/*@RequestMapping(value="/text")
	public sender sendtext() {
		sender s=new sender();
		s.setName("Pavan");
		return s;
	}*/
	
	@RequestMapping(value="/sendMsg",method=RequestMethod.POST)
	public message recieveMessage(@RequestBody message m) {
		repo.save(m);
		return m;
	}
	
	@RequestMapping(value="/sendSimple")
	public String receiveSimpleMessage( String s) {
		
		return s;
	}
	
	@RequestMapping(value="/getMsg")
	public message getMessage(int id) {
		
		return repo.getOne(id);
	}
	
	
@RequestMapping(value="/message1",method=RequestMethod.GET)
	public message getMsg(String text) {

	
		return repo.getByText(text);
	} 
	
	
}
