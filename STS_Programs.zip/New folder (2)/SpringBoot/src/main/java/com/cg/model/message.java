package com.cg.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
public class message {
	
	@Id
	@GeneratedValue
	private int mid;
	
	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	private String text;
	
	@OneToOne(cascade=CascadeType.ALL , fetch=FetchType.LAZY)
	private sender send;
	public sender getSend() {
		return send;
	}

	public void setSend(sender send) {
		this.send = send;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
