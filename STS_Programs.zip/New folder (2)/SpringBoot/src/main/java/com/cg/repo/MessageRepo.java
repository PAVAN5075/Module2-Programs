package com.cg.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.model.message;

public interface MessageRepo extends JpaRepository<message, Integer>{

	@Query(value="select m from message m where m.text=(:text)")
	message getByText(@Param(value="text")String text);  
}
