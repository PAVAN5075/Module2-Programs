package com.cg.controller;

import java.util.List;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.service.IProductService;


@RestController
@Transactional
@PersistenceContext

/*Class name: ProductManagementSystemController

5 Methods : createProduct, updateProduct, deleteProduct, viewProduct, findProductById

Author: Pavan Sudhakar Komarraju*/

public class ProductManagementSystemController {
	
	@Autowired
	private IProductService service;
	
	@RequestMapping(value="/createProduct",method=RequestMethod.POST)
	public Product createProduct(@RequestBody Product product) throws ProductException {
		
		try {
			Product product2=service.createProduct(product);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			System.err.println(e.getMessage());
			throw new ProductException(e.getMessage());
		}
		return product;
		
	}
	
	@RequestMapping(value="/updateProduct",method=RequestMethod.PUT)
	public Product updateProduct(@RequestBody Product product) {
		
		try {
			product=service.updateProduct(product);
			
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		return product;
	}
	
	@RequestMapping(value="/deleteProduct",method=RequestMethod.DELETE)
	public String deleteProduct(String id) {
		
		try {
			service.deleteProduct(id);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		return id;
	}
	
	@RequestMapping(value="/viewProduct",method=RequestMethod.GET)
	public List<Product> viewProduct() {
		List<Product> products=null;
		try {
			products=service.viewProduct();
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		return products;
		
	}
	
	@RequestMapping(value="/findProductById",method=RequestMethod.GET)
	public Product findProductById(String id) {
		Product product=null;
		try {
			product=service.findProductById(id);
		} catch (ProductException e) {
			// TODO Auto-generated catch block
			e.getMessage();
		}
		return product;
		
		
	}
	
}
