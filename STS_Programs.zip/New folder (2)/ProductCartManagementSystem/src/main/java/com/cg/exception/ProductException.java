package com.cg.exception;

/*Class name: ProductException

A User defined Exception Class Product Exception

Author: Pavan Sudhakar Komarraju*/

public class ProductException extends Exception {

	public ProductException(){
		super();
	}
	public ProductException(String message){
		super(message);
	}

}
