package com.cg.service;

import java.util.List;

import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.bean.Product;
import com.cg.exception.ProductException;
import com.cg.repo.ProductRepo;

/*Class name: ProductManagementSystemController

5 Methods : createProduct, updateProduct, deleteProduct, viewProduct, findProductById

Author: Pavan Sudhakar Komarraju*/

@Service
@PersistenceContext
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	private ProductRepo repo;
	

	@Override
	public Product createProduct(Product product) throws ProductException {
		if(validateProduct(product)) {
		repo.save(product);
		}
		else {
			throw new ProductException("Validation Failed");
		}
		return product;
	}

	@Override
	public Product updateProduct(Product product) throws ProductException {
		// TODO Auto-generated method stub
		
		Product product2=repo.getOne(product.getId());
		String name=product.getName();
		String model=product.getModel();
		double price=product.getPrice();
		if(name!=null) {
			product2.setName(product.getName());
		}
		if(model!=null) {
			product2.setModel(product.getModel());
		}
		
		if(price!=0) {
			product2.setPrice(product.getPrice());
		}
		repo.save(product2);
		
		return product2;
	}

	@Override
	public String deleteProduct(String id) throws ProductException {
		// TODO Auto-generated method stub
		
		repo.deleteById(id);
		return id;
	}

	@Override
	public List<Product> viewProduct() throws ProductException {
		// TODO Auto-generated method stub
		
		return repo.findAll();
	}

	@Override
	public Product findProductById(String id) throws ProductException {
		// TODO Auto-generated method stub
		
		return repo.getOne(id);
	}
	
	private boolean validateProduct(Product product1) throws ProductException {
		

		if(product1.getName().isEmpty())
			throw new ProductException("Product Name cannot be empty");
		if(product1.getModel().isEmpty())
			throw new ProductException("Model name should not be empty");
		if(product1.getPrice()<0)
			throw new ProductException("Product price cannot be zero or negative");
		return true;
	}
	

}
