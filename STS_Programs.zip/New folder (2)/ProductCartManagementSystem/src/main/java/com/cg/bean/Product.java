package com.cg.bean;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer","handler"})
@Entity
public class Product implements Serializable{
	
	/*Class name: Product
	
	4 Attributes : String id(pk), String name, String Model, Double Price 
	and appropriate settrts and getters
	
	Author: Pavan Sudhakar Komarraju*/
	
	
	
	@Id
	private String id;
	private String name;
	private String model;
	private Double price;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
	}
	
}
