package com.cg.SpringJPASample.exception;

public class EmployeeException extends Exception {
	public EmployeeException(){

	}
	public EmployeeException(String message){
		super(message);
	}

}
